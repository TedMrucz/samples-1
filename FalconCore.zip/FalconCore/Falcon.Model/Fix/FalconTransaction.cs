﻿using System.Collections.Generic;
using System.Xml.Serialization;
using BMO.Falcon.Model.Gloss;
using Newtonsoft.Json;

namespace BMO.Falcon.Model.Fix
{
	[XmlRoot("Transaction")]
	public class FalconTransaction : Transaction
	{
		[XmlElement("Date"), JsonIgnore]
		public List<TransactionDate> Dates { get; set; }
		[XmlElement("Amount"), JsonIgnore]
		public List<TransactionAmount> Amounts { get; set; }

		public void PrepareSerialization()
		{
			Dates = new List<TransactionDate>();
			Amounts = new List<TransactionAmount>();

			Dates.Add(OrderDate);
			Dates.Add(SettleDate);

			Amounts.Add(OrderAmount);
			Amounts.Add(SettleAmount);
		}
	}
}
