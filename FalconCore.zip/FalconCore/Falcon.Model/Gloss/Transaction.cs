﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace BMO.Falcon.Model.Gloss
{
	public class Transaction
	{
		[XmlElement("Ver")]
		public int Identifier { get; set; }                    //1
		[XmlElement("Name")]
		public string Name { get; set; }                       //2
		[XmlIgnore]
		public TransactionDate OrderDate { get; set; }         //3
		[XmlIgnore]
		public TransactionDate SettleDate { get; set; }        //4
		[XmlIgnore]
		public TransactionAmount OrderAmount { get; set; }    //5
		[XmlIgnore]
		public TransactionAmount SettleAmount { get; set; }   //6
		[XmlElement("Smb")]
		public string Symbol { get; set; }                   //8
		[XmlElement("Comp")]
		public bool IsFinal { get; set; }                    //9
		[XmlElement("Flag")]
		public char Flag { get; set; }                       //43
	}
}
