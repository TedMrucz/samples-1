﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Xml.Serialization;

namespace BMO.Falcon.Model.Gloss
{
	public class TransactionAmount
	{
		public string Type { get; set; }
		public string Currency { get; set; }
		public double Amount { get; set; }
	}
}
