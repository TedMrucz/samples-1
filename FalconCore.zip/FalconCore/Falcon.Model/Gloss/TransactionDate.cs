﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BMO.Falcon.Model.Gloss
{
	public class TransactionDate
	{
		public string Type { get; set; }
		public DateTime Date { get; set; }
	}
}
