﻿using System;
using System.Diagnostics;

namespace BMO.Gloss.Service
{
	public class QuickFixGlossService
	{
		public void HandleFixXmlFormat(string fixFormat)
		{
			if (!String.IsNullOrEmpty(fixFormat))
				Debug.WriteLine(fixFormat);
		}

		public void HandleFixJsonFormat(string fixFormat)
		{
			if (!String.IsNullOrEmpty(fixFormat))
				Debug.WriteLine(fixFormat);
		}
	}
}
