﻿using System;
using Confluent.Kafka;

namespace BMO.Kafka.Gloss
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Hello Gloss");
		}
	}
}
