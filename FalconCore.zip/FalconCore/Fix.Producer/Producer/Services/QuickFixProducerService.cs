﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;

namespace BMO.Producer.Service
{
	public class QuickFixProducerService
	{
		public async Task ProduceFixMsgs()
		{
			IList<string> fixMsgs = new List<string>()
							{
								@"1=12|2=2019.01.28|3=2019.02.01|4=MSFC|5=12456.56|6=5432.12|8=OBK|9=true|10=USD|11=USD|43=A|",
								@"1=22|2=2019.02.14|3=2019.03.11|4=Dell|5=74567.89|6=2345.45|8=DFG|9=false|10=CAD|11=USD|43=X|",
								@"1=34|2=2019.03.24|3=2019.03.17|4=ADAx|5=46557.09|6=2165.35|8=VDA|9=true|10=CAD|1=USD|43=C|",
								@"1=17|2=2019.04.04|3=2019.06.21|4=TDXQ|5=67000.62|6=9345.25|8=WDQ|9=false|10=CAD|11=CAD|43=B|",
								@"1=99|2=2018.01.28|3=2019.02.01|4=ADAS|5=12456.56|6=5432.12|8=QWE|9=true|10=USD|11=USD|43=F|",
								@"1=57|2=2014.02.17|3=2019.03.11|4=Bell|5=74567.89|6=2345.45|8=TRE|9=false|10=CAD|11=USD|43=Z|",
								@"1=23|2=2017.03.22|3=2019.03.17|4=MACS|5=46857.09|6=2165.35|8=YUT|9=true|10=USD|11=CAD|43=U|",
								@"1=76|2=2012.05.23|3=2019.06.21|4=TDXQ|5=34500.62|6=9345.25|8=BFD|9=false|10=CAD|11=USD|43=W|",
								@"1=31|2=2018.07.29|3=2019.02.01|4=YBFS|5=65456.56|6=5432.12|8=NBY|9=true|10=USD|11=CAD|43=Q|",
								@"1=44|2=2014.02.06|3=2019.03.11|4=ANBG|5=72367.89|6=2345.45|8=QQF|9=false|10=CAD|11=USD|43=V|"
							};

			var random = new Random();
			var client = new HttpClient();

			for (var i = 0; i < 20; ++i)
			{
				var index = random.Next(0, 9);

				var url = $"http://localhost:5001/services/FalconFix/SubmitXmlTransactionFixMsgToGloss?fixMsg={fixMsgs[index]}";
				var result = await client.GetStringAsync(url);

				Debug.WriteLine(result);
			}
		}
	}
}