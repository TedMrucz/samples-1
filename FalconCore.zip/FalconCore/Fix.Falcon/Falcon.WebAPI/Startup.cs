﻿using BMO.Falcon.WebAPI.Extensions;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace BMO.Falcon.WebAPI
{
	public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
			services.AddMvcCore(o =>
			{
				o.Conventions.Add(new PocoControllerModelConvention());
				o.ModelMetadataDetailsProviders.Add(new FromBodyBindingMetadataProvider());
				//o.InputFormatters.Add(new FileUploadInputFormatter());
				o.Filters.Add(new ModelStateValidationFilterAttribute());
			})
			.AddJsonFormatters()
			.AddCors()
			.AddApplicationPart(typeof(Constans).Assembly)
			.ConfigureApplicationPartManager(m => m.FeatureProviders.Add(new PocoControllerFeatureProvider()));
		}

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseMvc();

			app.UseMvc(r =>
			{
				r.MapRoute("default", "services/{controller}/{action}");
			});
		}
    }
}
