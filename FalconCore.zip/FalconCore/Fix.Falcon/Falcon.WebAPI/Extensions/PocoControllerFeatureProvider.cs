using System;
using System.Reflection;
using Microsoft.AspNetCore.Mvc.Controllers;

namespace BMO.Falcon.WebAPI.Extensions
{
	internal sealed class PocoControllerFeatureProvider : ControllerFeatureProvider
	{
		protected override bool IsController(TypeInfo typeInfo)
		{
			var isController = base.IsController(typeInfo);
			if (!isController)
				isController = typeInfo.Name.EndsWith("Service", StringComparison.OrdinalIgnoreCase) && typeInfo.IsPublic && !typeInfo.IsAbstract && typeInfo.IsClass;

			return isController;
		}
	}
}