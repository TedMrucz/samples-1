using System;
using System.Threading;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ModelBinding.Metadata;

namespace BMO.Falcon.WebAPI.Extensions
{
	internal sealed class FromBodyBindingMetadataProvider : IBindingMetadataProvider
	{
		public void CreateBindingMetadata(BindingMetadataProviderContext context)
		{
			if (!typeof(IConvertible).IsAssignableFrom(context.Key.ModelType) &&
				!typeof(Guid).IsAssignableFrom(context.Key.ModelType) &&
				!typeof(CancellationToken).IsAssignableFrom(context.Key.ModelType))
				context.BindingMetadata.BindingSource = BindingSource.Body;
		}
	}
}
