using System;
using Microsoft.AspNetCore.Mvc.ApplicationModels;

namespace BMO.Falcon.WebAPI.Extensions
{
	internal sealed class PocoControllerModelConvention : IControllerModelConvention
	{
		public void Apply(ControllerModel controller)
		{
			if (controller.ControllerName.EndsWith("Service", StringComparison.OrdinalIgnoreCase))
				controller.ControllerName = controller.ControllerName.Replace("Service", String.Empty, StringComparison.OrdinalIgnoreCase);
		}
	}
}