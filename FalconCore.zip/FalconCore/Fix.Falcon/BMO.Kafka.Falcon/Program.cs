﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Confluent.Kafka;

namespace BMO.Kafka.Falcon
{
	class Program
	{
		public static void Main(string[] args)
		{
			var conf = new ConsumerConfig
			{
				GroupId = "test-consumer-group",
				BootstrapServers = "localhost:9092",
				AutoOffsetReset = AutoOffsetResetType.Earliest
			};

			using (var c = new Consumer<Ignore, string>(conf))
			{
				c.Subscribe("fix-msg");

				bool consuming = true;

				c.OnError += (_, e) => consuming = !e.IsFatal;

				while (consuming)
				{
					try
					{
						var cr = c.Consume();
						Console.WriteLine($"Consumed message '{cr.Value}' at: '{cr.TopicPartitionOffset}'.");
					}
					catch (ConsumeException e)
					{
						Console.WriteLine($"Error occured: {e.Error.Reason}");
					}
				}

				// Ensure the consumer leaves the group cleanly and final offsets are committed.
				c.Close();
			}
		}
	}
}
