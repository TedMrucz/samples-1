﻿using System.Net.Http;
using System.Threading.Tasks;
using BMO.Falcon.Model.Fix;

namespace BMO.Falcon.QuickFixParser
{
	public class FalconFixService
	{
		public string TransactionFixMsgToJson(string fixMsg)
		{
			var fixObj = new TransactionHandle<FalconTransaction>(new FalconTransaction());
			fixObj.ParseFixMsgFields(fixMsg);

			return fixObj.SerializeToJson();
		}

		public string TransactionFixMsgToXml(string fixMsg)
		{
			var fixObj = new TransactionHandle<FalconTransaction>(new FalconTransaction());
			fixObj.ParseFixMsgFields(fixMsg);

			return fixObj.SerializeToXml();
		}

		public async Task SubmitXmlTransactionFixMsgToGloss(string fixMsg)
		{
			var fixObj = new TransactionHandle<FalconTransaction>(new FalconTransaction());
			fixObj.ParseFixMsgFields(fixMsg);

			var fixFormat = fixObj.SerializeToXml();

			var client = new HttpClient();
			var url = $"http://localhost:5002/services/QuickFixGloss/HandleFixXmlFormat?fixFormat={fixFormat}";
			var result = await client.GetStringAsync(url);
		}
	}
}
