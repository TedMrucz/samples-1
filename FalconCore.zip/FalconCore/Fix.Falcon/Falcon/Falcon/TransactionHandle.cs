﻿using System;
using BMO.Falcon.Model.Fix;
using BMO.Falcon.Model.Gloss;
using BMO.Falcon.Parser;

namespace BMO.Falcon.QuickFixParser
{
	public class TransactionHandle<T> : FixMsgHandle<T> where T : FalconTransaction
	{
		public TransactionHandle(T fixObj)
		{
			base.FixObj = fixObj;
		}

		public override T ConstructFixObj()
		{
			try
			{
				base.FixObj.Identifier = base.GetInt(Constans.Identifier);
				base.FixObj.Name = base.GetString(Constans.Name);
				base.FixObj.Symbol = base.GetString(Constans.Symbol);
				base.FixObj.IsFinal = base.GetBoolean(Constans.IsFinal);
				base.FixObj.Flag = base.GetChar(Constans.Flag);

				base.FixObj.OrderDate = new TransactionDate() { Type = "ODR", Date = base.GetDateTime(Constans.OrderDate) };
				base.FixObj.SettleDate = new TransactionDate() { Type = "SET", Date = base.GetDateTime(Constans.SettleDate) };

				base.FixObj.OrderAmount = new TransactionAmount() { Type = "OAMT", Currency = base.GetString(Constans.OrdCurrency), Amount = base.GetDouble(Constans.OrderAmount) };
				base.FixObj.SettleAmount = new TransactionAmount() { Type = "SAMT", Currency = base.GetString(Constans.SetCurrency), Amount = base.GetDouble(Constans.SettleAmount) };
			}
			catch (Exception e)
			{
				//Console.WriteLine(e.Message);
			}
			finally
			{
				base.FixObj.PrepareSerialization();
			}
	
			return base.FixObj;
		}
	}
}
