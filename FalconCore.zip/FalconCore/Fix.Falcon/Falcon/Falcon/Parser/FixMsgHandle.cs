﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using Newtonsoft.Json;

namespace BMO.Falcon.Parser
{
	public abstract class FixMsgHandle<T>
	{
		private Dictionary<int, string> DDFixFields = new Dictionary<int, string>();
		private Dictionary<int, string> MultiDDFixFields = new Dictionary<int, string>();

		public T FixObj { get; set; }

		public virtual T ConstructFixObj() { return this.FixObj; }

		public bool ParseFixMsgFields(string line)
		{
			this.DDFixFields.Clear();
			this.MultiDDFixFields.Clear();

			bool retValue = false;
			int index = 0;

			string[] cells = line.Split('|');

			foreach (var cell in cells)
			{
				if (!String.IsNullOrEmpty(cell))
				{
					string[] map = cell.Split('=');

					if (!String.IsNullOrEmpty(map[0]) && int.TryParse(map[0], out index))
					{
						if (this.DDFixFields.ContainsKey(index))
						{
							this.DDFixFields[index] = this.DDFixFields[index] + '|' + map[1];
							this.MultiDDFixFields[index] = this.DDFixFields[index];
						}
						else
							this.DDFixFields.Add(index, map[1]);
					}
				}
			}

			if (0 < this.DDFixFields.Count)
			{
				this.ConstructFixObj();
				retValue = true;
			}

			return retValue;
		}


		public string SerializeToJson()
		{
			return JsonConvert.SerializeObject(this.FixObj);
		}

		public string SerializeToXml()
		{
			string xmlOutput = String.Empty;

			try
			{
				XmlSerializer serializer = new XmlSerializer(typeof(T));

				using (var sww = new StringWriter())
				{
					using (XmlWriter writer = XmlWriter.Create(sww))
					{
						serializer.Serialize(writer, this.FixObj);
						xmlOutput = sww.ToString();
					}
				}
			}
			catch (Exception e)
			{
				xmlOutput = e.Message;
			}

			return xmlOutput;
		}

		protected string GetString(int key)
		{
			return this.DDFixFields[key];
		}

		protected char GetChar(int key)
		{
			if (String.IsNullOrEmpty(this.DDFixFields[key]))
				return this.DDFixFields[key][0];
		
			return ' ';
		}

		protected int GetInt(int key)
		{
			int val = 0;
			Int32.TryParse(this.DDFixFields[key], out val);

			return val;
		}

		protected double GetDouble(int key)
		{
			double val = 0;
			Double.TryParse(this.DDFixFields[key], out val);

			return val;
		}

		protected decimal GetDecimal(int key)
		{
			decimal val = 0;
			Decimal.TryParse(this.DDFixFields[key], out val);

			return val;
		}

		protected DateTime GetDateTime(int key)
		{
			DateTime val = DateTime.Today;
			DateTime.TryParse(this.DDFixFields[key], out val);

			return val;
		}

		protected bool GetBoolean(int key)
		{
			bool val = false;
			Boolean.TryParse(this.DDFixFields[key], out val);

			return val;
		}
	}
}
