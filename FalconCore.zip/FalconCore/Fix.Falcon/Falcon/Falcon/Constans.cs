﻿namespace BMO.Falcon
{
	public class Constans
	{
		public const int Identifier = 1;
		public const int Name = 2;
		public const int OrderDate = 3;
		public const int SettleDate = 4;
		public const int OrderAmount = 5;
		public const int SettleAmount = 6;
		public const int Symbol = 8;
		public const int IsFinal = 9;
		public const int OrdCurrency = 10;
		public const int SetCurrency = 11;
		public const int Flag = 43;
	}
}
