﻿using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace BMO.Falcon.Client
{
	class Program
	{
		static async Task Main(string[] args)
		{
			Console.WriteLine("Hello Falcon.Client");

			var client = new HttpClient();
			var url = "http://localhost:5000/services/QuickFixProducer/ProduceFixMsgs";
			await client.GetStringAsync(url);

			Console.ReadKey();
		}
	}
}