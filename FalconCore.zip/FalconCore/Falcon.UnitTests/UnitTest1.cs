using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;
using BMO.Falcon.QuickFixParser;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
	[TestClass]
	public class UnitTest1
	{
		[TestMethod]
		public void TestMethod1()
		{
			var fileName = "..\\..\\..\\Data\\Transactions.txt";

			if (!File.Exists(fileName))
			{
				Debug.WriteLine("Cannot read file:  ..\\Data\\Transactions.txt");
				return;
			}
			else
			{
				using (var textReader = new StreamReader(fileName))
				{
					string line;
					while ((line = textReader.ReadLine()) != null)
					{
						var parser = new FalconFixService();
						var json = parser.TransactionFixMsgToJson(line);
					}
				}
			}
		}

		[TestMethod]
		public void TestMethod2()
		{
			var fileName = "..\\..\\..\\Data\\Transactions.txt";

			if (!File.Exists(fileName))
			{
				Debug.WriteLine("Cannot read file:  ..\\Data\\Transactions.txt");
				return;
			}
			else
			{
				using (var textReader = new StreamReader(fileName))
				{
					string line;
					while ((line = textReader.ReadLine()) != null)
					{
						var parser = new FalconFixService();
						var xml = parser.TransactionFixMsgToXml(line);
					}
				}
			}
		}

		[TestMethod]
		public async Task TcpClientTest()
		{
			var client = new TcpClient();
			await client.ConnectAsync(IPAddress.Loopback, 5000);
		}

		[TestMethod]
		public async Task TcpListenerTest()
		{
			var client = new TcpListener(IPAddress.Loopback, 5000);
			client.Start();
			await client.AcceptSocketAsync();
		}
	}
}
